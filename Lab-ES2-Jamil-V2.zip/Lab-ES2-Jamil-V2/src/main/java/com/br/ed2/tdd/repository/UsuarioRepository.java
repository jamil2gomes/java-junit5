package com.br.ed2.tdd.repository;

import com.br.ed2.tdd.modelo.Usuario;

public interface UsuarioRepository {

	void salvar(Usuario usuario);
}
