package com.br.ed2.tdd.repository;

import com.br.ed2.tdd.modelo.Pagamento;

public interface PagamentoRepository {

	String salva(Pagamento pagamento);
}
